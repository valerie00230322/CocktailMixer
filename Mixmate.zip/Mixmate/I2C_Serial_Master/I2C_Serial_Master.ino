#include <Wire.h>

const byte DEFAULT_SLAVE_ADDRESS = 0x12;  // Regal-Slave
byte activeSlaveAddress = DEFAULT_SLAVE_ADDRESS;
bool slaveReady = false;
String inputLine = "";
uint32_t bootCounter = 0;

enum CommandCode : uint8_t {
  CMD_LIFT = 0,
  CMD_HOME = 1,
  CMD_STATUS = 2,
  CMD_EBENE = 3,
  CMD_BELADEN = 4,
  CMD_ENTLADEN = 5,
  CMD_AUSSCHUB = 6,
  CMD_AUSSCHUB_HOME = 7
};

const uint8_t LEVEL_1 = 1;
const uint8_t LEVEL_2 = 2;
const uint8_t LEVEL_WAIT = 3;

// ==============================
// Setup / Loop
// ==============================
void setup() {
  Serial.begin(115200);
  Wire.begin();
  delay(2000);

  bootCounter++;

  Serial.println();
  Serial.println("================================");
  Serial.print("Boot #");
  Serial.println(bootCounter);
  Serial.println("I2C Master fuer Regal bereit.");
  Serial.print("Suche I2C-Slave auf Adresse 0x");
  if (DEFAULT_SLAVE_ADDRESS < 16) {
    Serial.print("0");
  }
  Serial.println(DEFAULT_SLAVE_ADDRESS, HEX);
  Serial.println();
  printHelp();
  waitForSlave();
}

void loop() {
  while (Serial.available() > 0) {
    char c = Serial.read();

    if (c == '\n' || c == '\r') {
      if (inputLine.length() > 0) {
        handleCommand(inputLine);
        inputLine = "";
      }
    } else {
      inputLine += c;
    }
  }
}

// ==============================
// Bedienhilfe
// ==============================
void printHelp() {
  Serial.println("Befehle:");
  Serial.println("  help");
  Serial.println("  status");
  Serial.println("  home");
  Serial.println("  lift <mm>");
  Serial.println("  ausschub <mm>");
  Serial.println("  ausschub_home");
  Serial.println("  ebene <1|2|3|warte> [vor|zurueck]");
  Serial.println("  ebene1 [vor|zurueck]");
  Serial.println("  ebene2 [vor|zurueck]");
  Serial.println("  warte [vor|zurueck]");
  Serial.println("  beladen");
  Serial.println("  entladen");
  Serial.println();
  Serial.println("Hinweis:");
  Serial.println("  Erst Ebene waehlen, dann beladen oder entladen.");
  Serial.println("  So kann jede Ebene einzeln getestet werden.");
  Serial.println("  Ebene 3 / warte = Wartepositionsband.");
  Serial.println();
}

// ==============================
// Kommandoauswertung
// ==============================
void handleCommand(String line) {
  if (!slaveReady) {
    Serial.println("Noch kein I2C-Slave gefunden.");
    waitForSlave();
    return;
  }

  line.trim();
  if (line.length() == 0) {
    return;
  }

  int spacePos = line.indexOf(' ');
  String cmd = line;
  String arg = "";

  if (spacePos >= 0) {
    cmd = line.substring(0, spacePos);
    arg = line.substring(spacePos + 1);
    arg.trim();
  }

  cmd.toLowerCase();
  arg.toLowerCase();

  if (cmd == "help" || cmd == "?") {
    printHelp();
    return;
  }

  if (cmd == "lift") {
    if (arg.length() == 0) {
      Serial.println("Fehler: lift braucht einen mm-Wert.");
      return;
    }
    sendInt16Command(CMD_LIFT, (int16_t)arg.toInt(), "lift");
    return;
  }

  if (cmd == "ausschub") {
    if (arg.length() == 0) {
      Serial.println("Fehler: ausschub braucht einen mm-Wert.");
      return;
    }
    sendInt16Command(CMD_AUSSCHUB, (int16_t)arg.toInt(), "ausschub");
    return;
  }

  if (cmd == "ebene") {
    handleSelectLevelCommand(arg);
    return;
  }

  if (cmd == "ebene1") {
    handleDirectLevelCommand(LEVEL_1, arg, "Ebene 1");
    return;
  }

  if (cmd == "ebene2") {
    handleDirectLevelCommand(LEVEL_2, arg, "Ebene 2");
    return;
  }

  if (cmd == "warte") {
    handleDirectLevelCommand(LEVEL_WAIT, arg, "Warteposition");
    return;
  }

  if (cmd == "home") {
    sendSimpleCommand(CMD_HOME, "home");
    return;
  }

  if (cmd == "beladen") {
    sendSimpleCommand(CMD_BELADEN, "beladen");
    return;
  }

  if (cmd == "entladen") {
    sendSimpleCommand(CMD_ENTLADEN, "entladen");
    return;
  }

  if (cmd == "ausschub_home") {
    sendSimpleCommand(CMD_AUSSCHUB_HOME, "ausschub_home");
    return;
  }

  if (cmd == "status") {
    requestStatus();
    return;
  }

  Serial.println("Unbekannter Befehl. Mit help bekommst du die Liste.");
}

void handleSelectLevelCommand(const String& arg) {
  if (arg.length() == 0) {
    Serial.println("Fehler: ebene braucht 1, 2 oder 3 / warte.");
    return;
  }

  uint8_t level = LEVEL_1;
  bool hasDirection = false;
  bool directionForward = true;

  if (!parseLevelAndDirection(arg, level, hasDirection, directionForward)) {
    return;
  }

  sendLevelCommand(level, hasDirection, directionForward);
}

void handleDirectLevelCommand(uint8_t level, const String& arg, const char* label) {
  bool hasDirection = false;
  bool directionForward = true;

  if (arg.length() > 0) {
    if (!parseDirectionToken(arg, directionForward)) {
      Serial.println("Fehler: Richtung nur vor oder zurueck.");
      return;
    }
    hasDirection = true;
  }

  sendLevelCommand(level, hasDirection, directionForward);

  Serial.print("Aktive Auswahl: ");
  Serial.println(label);
}

bool parseLevelAndDirection(const String& arg, uint8_t& level, bool& hasDirection, bool& directionForward) {
  int argSpacePos = arg.indexOf(' ');
  String levelToken = arg;
  String directionToken = "";

  if (argSpacePos >= 0) {
    levelToken = arg.substring(0, argSpacePos);
    directionToken = arg.substring(argSpacePos + 1);
    directionToken.trim();
  }

  if (!parseLevelToken(levelToken, level)) {
    Serial.println("Fehler: Ebene erlaubt nur 1, 2 oder 3 / warte.");
    return false;
  }

  hasDirection = false;
  directionForward = true;

  if (directionToken.length() > 0) {
    if (!parseDirectionToken(directionToken, directionForward)) {
      Serial.println("Fehler: Richtung nur vor oder zurueck.");
      return false;
    }
    hasDirection = true;
  }

  return true;
}

bool parseLevelToken(String token, uint8_t& level) {
  token.trim();
  token.toLowerCase();

  if (token == "1" || token == "ebene1") {
    level = LEVEL_1;
    return true;
  }

  if (token == "2" || token == "ebene2") {
    level = LEVEL_2;
    return true;
  }

  if (token == "3" || token == "warte" || token == "wait") {
    level = LEVEL_WAIT;
    return true;
  }

  return false;
}

bool parseDirectionToken(String token, bool& directionForward) {
  token.trim();
  token.toLowerCase();

  if (token == "vor" || token == "vorwaerts" || token == "vorwarts" || token == "forward") {
    directionForward = true;
    return true;
  }

  if (token == "zurueck" || token == "rueckwaerts" || token == "ruckwaerts" || token == "back" || token == "backward") {
    directionForward = false;
    return true;
  }

  return false;
}

uint8_t encodeLevelValue(uint8_t level, bool hasDirection, bool directionForward) {
  uint8_t encoded = (uint8_t)(level & 0x3Fu);

  if (hasDirection) {
    encoded |= 0x40u;
    if (directionForward) {
      encoded |= 0x80u;
    }
  }

  return encoded;
}

void sendLevelCommand(uint8_t level, bool hasDirection, bool directionForward) {
  uint8_t encodedLevel = encodeLevelValue(level, hasDirection, directionForward);
  sendByteCommand(CMD_EBENE, encodedLevel, "ebene");
}

// ==============================
// I2C senden
// ==============================
void sendSimpleCommand(uint8_t cmd, const char* label) {
  Wire.beginTransmission(activeSlaveAddress);
  Wire.write(cmd);
  byte error = Wire.endTransmission();
  printResult(label, error);
}

void sendByteCommand(uint8_t cmd, uint8_t value, const char* label) {
  Wire.beginTransmission(activeSlaveAddress);
  Wire.write(cmd);
  Wire.write(value);
  byte error = Wire.endTransmission();

  Serial.print("Gesendet: ");
  Serial.print(label);
  Serial.print(" ");
  Serial.print(value & 0x3Fu);
  if ((value & 0x40u) != 0u) {
    Serial.print(" ");
    Serial.println((value & 0x80u) != 0u ? "vor" : "zurueck");
  } else {
    Serial.println();
  }
  printErrorOnly(error);
}

void sendInt16Command(uint8_t cmd, int16_t value, const char* label) {
  uint8_t low = (uint8_t)(value & 0xFF);
  uint8_t high = (uint8_t)((value >> 8) & 0xFF);

  Wire.beginTransmission(activeSlaveAddress);
  Wire.write(cmd);
  Wire.write(low);
  Wire.write(high);
  byte error = Wire.endTransmission();

  Serial.print("Gesendet: ");
  Serial.print(label);
  Serial.print(" ");
  Serial.println(value);
  printErrorOnly(error);
}

// ==============================
// Status lesen
// ==============================
void requestStatus() {
  Wire.beginTransmission(activeSlaveAddress);
  Wire.write(CMD_STATUS);
  byte error = Wire.endTransmission(false);

  if (error != 0) {
    printResult("status", error);
    return;
  }

  const uint8_t requested = 5;
  uint8_t received = Wire.requestFrom((int)activeSlaveAddress, (int)requested);

  if (received != requested) {
    Serial.print("Status-Fehler: Erwartet ");
    Serial.print(requested);
    Serial.print(" Bytes, erhalten: ");
    Serial.println(received);
    while (Wire.available()) {
      (void)Wire.read();
    }
    return;
  }

  uint8_t busy = Wire.read();
  uint8_t sensorFlags = Wire.read();
  uint8_t posLow = Wire.read();
  uint8_t posHigh = Wire.read();
  uint8_t isHomed = Wire.read();

  int16_t position = (int16_t)((uint16_t)posLow | ((uint16_t)posHigh << 8));

  Serial.println("Status empfangen:");
  Serial.print("  busy: ");
  Serial.println(busy ? "1" : "0");
  Serial.print("  position_mm: ");
  Serial.println(position);
  Serial.print("  is_homed: ");
  Serial.println(isHomed ? "1" : "0");
  Serial.print("  sensor_flags: 0b");
  Serial.println(sensorFlags, BIN);

  printFlagLine("lift_belegt", (sensorFlags & (1u << 0)) != 0u);
  printFlagLine("wait_start_belegt", (sensorFlags & (1u << 1)) != 0u);
  printFlagLine("wait_end_belegt", (sensorFlags & (1u << 2)) != 0u);
  printFlagLine("level1_front_belegt", (sensorFlags & (1u << 3)) != 0u);
  printFlagLine("level2_front_belegt", (sensorFlags & (1u << 4)) != 0u);
  printFlagLine("entladen_blocked", (sensorFlags & (1u << 6)) != 0u);
}

void printFlagLine(const char* label, bool value) {
  Serial.print("  ");
  Serial.print(label);
  Serial.print(": ");
  Serial.println(value ? "1" : "0");
}

// ==============================
// Slave finden
// ==============================
void waitForSlave() {
  while (!slaveReady) {
    if (scanForSlave()) {
      slaveReady = true;
      Serial.print("I2C-Slave gefunden auf Adresse 0x");
      if (activeSlaveAddress < 16) {
        Serial.print("0");
      }
      Serial.println(activeSlaveAddress, HEX);
      Serial.println("Befehle koennen jetzt gesendet werden.");
      return;
    }

    Serial.println("Kein I2C-Slave gefunden. Neuer Scan in 1 Sekunde...");
    delay(1000);
  }
}

bool scanForSlave() {
  Wire.beginTransmission(DEFAULT_SLAVE_ADDRESS);
  byte error = Wire.endTransmission();

  if (error == 0) {
    activeSlaveAddress = DEFAULT_SLAVE_ADDRESS;
    return true;
  }

  return false;
}

// ==============================
// Ausgabe
// ==============================
void printResult(const char* label, byte error) {
  Serial.print("Gesendet: ");
  Serial.println(label);
  printErrorOnly(error);
}

void printErrorOnly(byte error) {
  if (error == 0) {
    Serial.println("I2C: OK");
  } else {
    Serial.print("I2C Fehler, Code: ");
    Serial.println(error);
  }
}
